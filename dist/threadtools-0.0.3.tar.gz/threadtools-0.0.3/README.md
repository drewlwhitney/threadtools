# threadtools
Support for signals and better locks in native Python.
